<?php

declare(strict_types=1);

use WebtreesModules\KTheme\KTheme;

require __DIR__ . '/KTheme.php';

return new KTheme();
